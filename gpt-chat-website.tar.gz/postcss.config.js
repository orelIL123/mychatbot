{
  "plugins": [
    "tailwindcss",
    "autoprefixer"
  ]
}
